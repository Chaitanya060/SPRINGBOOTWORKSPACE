package com.klef.jfsd.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
